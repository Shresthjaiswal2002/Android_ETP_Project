package com.example.program_transfer_management

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class contactus : AppCompatActivity() {
    lateinit var submit:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contactus)
        var et1=findViewById<EditText>(R.id.et1)
        var et2=findViewById<EditText>(R.id.et2)
        var et3=findViewById<EditText>(R.id.et3)
        var et4=findViewById<EditText>(R.id.et4)
        submit=findViewById(R.id.submit)
        submit.setOnClickListener {
            val t1 = et1.text.toString()
            val t2 = et2.toString()
            val t3 = et3.text.toString()
            val t4 = et4.text.toString()
            if (t1.isEmpty() || t2.isEmpty() ||
                t3.isEmpty() || t4.isEmpty()
            ){
                Toast.makeText(this,"Please Fill out All the Details",Toast.LENGTH_SHORT).show()

            }
            else{
                Toast.makeText(this,"Sucessfully Submited",Toast.LENGTH_SHORT).show()
            }
        }

    }
}