package com.example.program_transfer_management

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.RatingBar
import android.widget.Toast

class MainActivity3_f : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_activity3_f)
        val simpleRatingBar = findViewById<RatingBar>(R.id.simpleRatingBar)
        val submitButton = findViewById<Button>(R.id.submitButton)

        submitButton.setOnClickListener {
            val totalStars = " Total Stars: " + simpleRatingBar.numStars
            val rating = " Rating: " + simpleRatingBar.rating
            Toast.makeText(
                this, """ $totalStars$rating""".trimIndent(),
                Toast.LENGTH_LONG
            ).show()
            Toast.makeText(this,"Thank You For Your Valuable Feedback",Toast.LENGTH_SHORT).show()
        }
    }
}