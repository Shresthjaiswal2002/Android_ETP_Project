package com.example.program_transfer_management

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class bottom_navigation : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bottom_navigation)
    }
}